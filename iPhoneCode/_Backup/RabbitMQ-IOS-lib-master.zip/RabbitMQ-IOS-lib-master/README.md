RabitMQ-IOS-lib
===============

this project is for RabbitMQ of IOS lib


how to use?

this way:
https://github.com/profmaad/librabbitmq-objc
