//
//  RabbitMQTViewController.m
//  RabbitMQT
//
//  Created by leisure huang on 12-7-2.
//  leisure.huang34@gmail.com
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "RabbitMQTViewController.h"
#import "ZM_MQHelper.h"

@interface RabbitMQTViewController ()

@property (strong, nonatomic) IBOutlet UITextView *consumerTextView;
@property (strong, nonatomic) IBOutlet UITextField *sendingTextFeild;

@property (retain,nonatomic) ZM_MQHelper *mHelper;
@property (retain,nonatomic) NSMutableString *mMessages;

@end

@implementation RabbitMQTViewController

#pragma mark -

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.mHelper=[ZM_MQHelper new];
    int status = [self.mHelper connect:@{
                            DKEY_MQS_HOST   :MQS_SERVER,
                            DKEY_MQS_PORT   :@(MQS_PORT),
                            DKEY_MQS_USER   :MQS_USER,
                            DKEY_MQS_PWD    :MQS_PWD
                            }];
    
    if (status>0) {
        NSLog(@"连接失败");
        return;
    } else {
        [self showMessage:@"连接成功"];
    }

    status = [self.mHelper bind:MQS_EXCHANGE_NAME
                 queue:MQS_QUEUE_NAME
                 route:@"#"
               andType:MQS_EXTYPE_FANOUT];
    
    if (status>0) {
        NSLog(@"绑定失败");
        return;
    } else {
        [self showMessage:@"绑定成功"];
    }
    
    [self.mHelper listen:^(int status,NSString *message){
            [self showMessage:message];
    }];
    
}

- (void)viewDidUnload
{
    if (self.mHelper) [self.mHelper unbind];
    [super viewDidUnload];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (IBAction) do_send:(id)sender
{
    if ([self.sendingTextFeild.text length] == 0) return;
    
    if (self.mHelper) {
        [self.mHelper publish:self.sendingTextFeild.text];
    }
    
    self.sendingTextFeild.text = @"";
    [self.sendingTextFeild resignFirstResponder];
}

- (IBAction)do_clear:(UIButton *)sender {
    if (self) {
        self.mMessages = [NSMutableString stringWithString: @""];
    }
    [self showMessage:@"已清除"];
}

-(void) showMessage:(NSString*) message
{
    if (!self.mMessages) {
        // init the String
        self.mMessages = [NSMutableString string];
    }

    [self.mMessages appendFormat:@"%@\n",message];
    [self.consumerTextView setText:self.mMessages];


}


@end
