//
//  RabbitMQTAppDelegate.h
//  RabbitMQT
//
//  Created by leisure huang on 12-7-2.
//  leisure.huang34@gmail.com
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class RabbitMQTViewController;

@interface RabbitMQTAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) RabbitMQTViewController *viewController;

@end
