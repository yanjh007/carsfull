//
//  RabbitMQTViewController.h
//  RabbitMQT
//
//  Created by leisure huang on 12-7-2.
//  leisure.huang34@gmail.com
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "amqp.h"

@interface RabbitMQTViewController : UIViewController



@end
