//
//  ZM_MQHelper.m
//  RabbitMQT
//
//  Created by john yan on 14/10/11.
//
//

#import "ZM_MQHelper.h"
#import "amqp.h"
#include <mach/mach.h>
#include <mach/mach_time.h>

#define SUMMARY_EVERY_US 1000000

@interface ZM_MQHelper() {

}

// must put here!!!

@property(assign) int sockfd;
@property(assign) amqp_connection_state_t conn; //连接
@property(assign) amqp_bytes_t queue; //队列

@property(assign) const char *exchange_name,*queue_name,*route_name;
@end

@implementation ZM_MQHelper

-(int) connect:(NSDictionary*)config
{
    amqp_rpc_reply_t reply;
    // Opening socket
    _conn = amqp_new_connection();
    _sockfd = amqp_open_socket([config[DKEY_MQS_HOST] UTF8String],[config[DKEY_MQS_PORT] integerValue]);
    
    // is the Service OK?
    if (_sockfd < 0) {
        NSLog(@"connect error!");
        return 1;
    }
    
    // Logging in
    amqp_set_sockfd(_conn, _sockfd);
    reply = amqp_login(_conn,"/", 0, 131072, 0, AMQP_SASL_METHOD_PLAIN, [config[DKEY_MQS_USER] UTF8String], [config[DKEY_MQS_PWD] UTF8String]);
    
    if (reply.reply_type != AMQP_RESPONSE_NORMAL) {
        NSLog(@"login error!");
        return 2;
    }
    
    // Opening channel
    amqp_channel_open(_conn, 1);
    amqp_get_rpc_reply(_conn);
    
    return 0;
    
}

-(int) bind:(NSString*)exName
      queue:(NSString*)qName
      route:(NSString*)rName
    andType:(NSString*)exType
{
    _exchange_name=[exName UTF8String];
    _queue_name = [qName UTF8String];
    _route_name = [rName UTF8String];
    
    // declare Exchange
    amqp_exchange_declare(_conn,
                          1,
                          amqp_cstring_bytes(_exchange_name),
                          amqp_cstring_bytes([exType UTF8String]),
                          0,
                          0,
                          amqp_empty_table);
    
    // declare Queue
    amqp_queue_declare_ok_t *r = amqp_queue_declare(
                                                    _conn,
                                                    1,
                                                    amqp_cstring_bytes(_queue_name)
                                                    , 0, 0, 0, 1,amqp_empty_table);
    
    // Declaring queue
    _queue = amqp_bytes_malloc_dup(r->queue);
    if (_queue.bytes == NULL) {
        NSLog(@"Out of memory while copying queue name");
        return 1;
    }
    
    // binding queue
    amqp_table_t amqp_empty_table;
    amqp_queue_bind(_conn,
                    1,
                    _queue,
                    amqp_cstring_bytes(_exchange_name),
                    amqp_cstring_bytes(_route_name),
                    amqp_empty_table);
    
    return 0;
}

-(int) publish:(NSString*) message //信息发布
{
    if (!message || message.length==0) {
        return 1;
    }
    
    amqp_get_rpc_reply(_conn);

    // Publishing
    {
    amqp_basic_properties_t props;
    props._flags = AMQP_BASIC_CONTENT_TYPE_FLAG | AMQP_BASIC_DELIVERY_MODE_FLAG;
    props.content_type = amqp_cstring_bytes("text/plain");
    props.delivery_mode = 2; /* persistent delivery mode */
    
    amqp_basic_publish(_conn,
                       1,
                       amqp_cstring_bytes(_exchange_name),
                       amqp_cstring_bytes(_route_name),
                       0,
                       0,
                       NULL,
                       amqp_cstring_bytes([message UTF8String]));
    }
    return 0;
}

-(void) listen:(void (^)(int status, NSString *message)) onReceive;
{
    // Consuming
    amqp_basic_consume(_conn, 1,_queue, amqp_empty_bytes, 0, 1, 0, amqp_empty_table);
    amqp_get_rpc_reply(_conn);
    
    // run in a dispatch async queue
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        // run(conn);
        printf("DEBUG:run consumer!\n");
        
        uint64_t start_time = mach_absolute_time();
        
        int received = 0;
        int previous_received = 0;
        uint64_t previous_report_time = start_time;
        uint64_t next_summary_time = start_time + SUMMARY_EVERY_US;
        amqp_frame_t frame;
        int result;
        size_t body_received;
        size_t body_target;
        uint64_t now;
        
        printf("DEBUG:do while\n");
        
        while (1) {
            now = mach_absolute_time();
            if (now > next_summary_time) {
                int countOverInterval = received - previous_received;
                double intervalRate = countOverInterval / ((now - previous_report_time) / 1000000.0);
                printf("DEBUG:%d ms: Received %d - %d since last report (%d Hz)\n",
                       (int)(now - start_time) / 1000, received, countOverInterval, (int) intervalRate);
                
                previous_received = received;
                previous_report_time = now;
                next_summary_time += SUMMARY_EVERY_US;
            }
            
            amqp_maybe_release_buffers(_conn);
            
            result = amqp_simple_wait_frame(_conn, &frame);
            if (result < 0) return;
            
            if (frame.frame_type != AMQP_FRAME_METHOD) continue;
            
            if (frame.payload.method.id != AMQP_BASIC_DELIVER_METHOD)  continue;
            
            result = amqp_simple_wait_frame(_conn, &frame);
            if (result < 0) return;
            
            if (frame.frame_type != AMQP_FRAME_HEADER) {
                fprintf(stderr, "Expected header!");
                abort();
            }
            
            body_target = frame.payload.properties.body_size;
            body_received = 0;
            
            while (body_received < body_target) {
                result = amqp_simple_wait_frame(_conn, &frame);
                if (result < 0)  return;
                
                if (frame.frame_type != AMQP_FRAME_BODY) {
                    NSLog(@"Expected body!");
                    abort();
                }
                
                body_received += frame.payload.body_fragment.len;
                assert(body_received <= body_target);
            }
            
            received++;
            
            // receive message
            NSMutableString *tempString = [NSMutableString string];
            printf("DEBUG:The message is:");
            for(int i = 0; i<frame.payload.body_fragment.len; i++) {
                printf("%c",*((char*)frame.payload.body_fragment.bytes+i));
                [tempString appendFormat:@"%c",*((char*)frame.payload.body_fragment.bytes+i)];
            }
            
            printf("\n");
            
            dispatch_async(dispatch_get_main_queue(), ^{
                onReceive(0,[tempString copy]);
            });
        }
    });
    
}


-(int) unbind //连接解绑并关闭
{
    // unbinding
    amqp_queue_unbind(_conn, 1,
                      _queue,
                      amqp_cstring_bytes(_exchange_name),
                      amqp_cstring_bytes(_route_name),
                      amqp_empty_table);
    
    // Closing channel
    amqp_channel_close(_conn, 1, AMQP_REPLY_SUCCESS);
    
    // Closing connection
    amqp_connection_close(_conn, AMQP_REPLY_SUCCESS);
    
    //Ending connection
    amqp_destroy_connection(_conn);
    
    return 0;
}


@end
