//
//  ZM_MQHelper.h
//  RabbitMQT
//
//  Created by john yan on 14/10/11.
//
//

#import <Foundation/Foundation.h>

static NSString *const BG_IMG_TITLE_BAR    = @"bg_nav";

static NSString *const MQS_SERVER=@"192.168.0.83";
static const int MQS_PORT=5672;

static NSString *const MQS_USER =@"teacher";
static NSString *const MQS_PWD  =@"hellottt";

static NSString *const MQS_EXCHANGE_NAME  =@"nba.scores";
static NSString *const MQS_QUEUE_NAME     =@"iosclient";

static NSString *const MQS_EXTYPE_FANOUT =@"fanout";
static NSString *const MQS_EXTYPE_TOPIC  =@"topic";


static NSString *const DKEY_MQS_USER =@"user";
static NSString *const DKEY_MQS_PWD  =@"passwd";
static NSString *const DKEY_MQS_HOST =@"host";
static NSString *const DKEY_MQS_PORT =@"port";

@interface ZM_MQHelper : NSObject
-(int) connect:(NSDictionary*)config;
-(int) bind:(NSString*)exName queue:(NSString*)qName route:(NSString*)rName andType:(NSString*)exType;
-(int) unbind;

-(int) publish:(NSString*) message;
-(void) listen:(void (^)(int status, NSString *message)) onReceive;

@end
