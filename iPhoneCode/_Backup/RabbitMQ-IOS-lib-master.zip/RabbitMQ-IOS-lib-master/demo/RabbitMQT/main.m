//
//  main.m
//  RabbitMQT
//
//  Created by leisure huang on 12-7-2.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "RabbitMQTAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([RabbitMQTAppDelegate class]));
    }
}
