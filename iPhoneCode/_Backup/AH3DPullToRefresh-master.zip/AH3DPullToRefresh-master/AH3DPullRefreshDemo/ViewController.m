/**
 Copyright (c) 2012 Albert Hernández López <albert.hernandez@gmail.com>
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is furnished
 to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in all
 copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 */

#import "ViewController.h"

#import "UIScrollView+AH3DPullRefresh.h"

#define kDataArray @[@"Ate", @"Bacchus Moon", @"Bel'Shir", @"Bivouac", @"Brutus", @"Canis", @"Chanuk", @"Dark moon", @"Edis", @"Ehlna", @"Ender", @"Eris", @"Gohbus Moon", @"Haji", @"Hermes", @"Kaldir", @"Luna", @"Monlyth", @"Orson", @"Paralta Moon", @"Pyramus", @"Roxara's moon", @"Saalok", @"Sue", @"Thisby", @"Thunis", @"Treason", @"Ulaan", @"Ursa", @"Urthos III", @"Valhalla", @"Vito", @"Worthing"]

#define kRowsInitSize 21
#define MIN_ITEM_COUNT_IN_APAGE 9

@interface ViewController () <UITableViewDataSource>
@property (assign) int iBegin,iEnd;

@property(nonatomic, retain) IBOutlet UITableView * tableView;
@property(nonatomic, retain) UITableView *tb_data;
@property(nonatomic, retain) NSMutableArray *ary_data;

- (IBAction)refreshButtonPressed:(id)sender;
- (IBAction)loadMoreButtonPressed:(id)sender;

@end

// --------------------------------------------------------------------------------
#pragma mark -

@implementation ViewController

@synthesize tableView = _tableView;

#pragma mark - View lifecycle

- (void)viewDidLoad {
    
    [super viewDidLoad];
    self.iBegin=8; self.iEnd=12;
    
    self.ary_data = [kDataArray copy];
    
    // Set the pull to refresh handler block
    __block ViewController *vc =self;
    [self.tableView setPullToRefreshHandler:^{
        [vc performSelector:@selector(dataRefresh:) withObject:nil afterDelay:2];
    }];
    
    // Set the pull to laod more handler block
    [self.tableView setPullToLoadMoreHandler:^{
        [vc performSelector:@selector(dataLoad:) withObject:nil afterDelay:2];
    }];
    
    [self.tableView setBackgroundColor:[UIColor whiteColor]];
    
    // Customization of the pull refresh view (optional). Uncomment to try ;-)
//    [_tableView setPullToRefreshViewBackgroundColor:[UIColor redColor]];
//    [_tableView setPullToRefreshViewBackgroundColor:[UIColor colorWithRed:0.1 green:0.3 blue:1.0 alpha:1.0]];
//    [[_tableView pullToRefreshLabel] setTextColor:[UIColor colorWithWhite:1.0 alpha:1.0]];
//    [_tableView setPullToRefreshViewActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite];
//    [_tableView setPullToRefreshViewLoadedText:@"Locked and loaded!"];
//    [_tableView setPullToRefreshViewLoadingText:@"Let me think..."];
//    [_tableView setPullToRefreshViewPullingText:@"A little bit more..."];
//    [_tableView setPullToRefreshViewReleaseText:@"NOW!"];
    
    // Customization of the pull to load more view (optional). Uncomment to try ;-)
//    [_tableView setPullToLoadMoreViewBackgroundColor:[UIColor colorWithRed:0.1 green:0.3 blue:1.0 alpha:1.0]];
//    [[_tableView pullToLoadMoreLabel] setTextColor:[UIColor colorWithWhite:1.0 alpha:1.0]];
//    [_tableView setPullToLoadMoreViewActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite];
//    [_tableView setPullToLoadMoreViewLoadedText:@"Locked and loaded!"];
//    [_tableView setPullToLoadMoreViewLoadingText:@"Let me think..."];
//    [_tableView setPullToLoadMoreViewPullingText:@"A little bit more..."];
//    [_tableView setPullToLoadMoreViewReleaseText:@"NOW!"];
}

- (void)viewDidUnload {
    [super viewDidUnload];
}

#pragma mark - Rotation support

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    
    return YES;
}

#pragma mark - Public methods

- (IBAction)refreshButtonPressed:(id)sender {
    
    [_tableView pullToRefresh];
}

- (IBAction)loadMoreButtonPressed:(id)sender {
    
    [_tableView pullToLoadMore];
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    int count=self.iEnd-self.iBegin;
    return count>MIN_ITEM_COUNT_IN_APAGE?count:MIN_ITEM_COUNT_IN_APAGE;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    // Cell reuse
    static NSString * cellIdentifier = @"Cell";
    
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] ;
    }
    
    // Cell customization
    UIView * bgView = [[UIView alloc] initWithFrame:cell.frame];
    [bgView setBackgroundColor:[UIColor whiteColor]];
    [cell setBackgroundView:bgView];
    
    [[cell textLabel] setBackgroundColor:[UIColor clearColor]];
    
    int i2= self.iEnd-self.iBegin;
    
    if (indexPath.row < i2) {
        [[cell textLabel] setText:self.ary_data[self.iBegin+indexPath.row]];
    } else {
        [[cell textLabel] setText:@""];
    }
    
    return cell;
}

#pragma mark - Private methods

- (void)dataRefresh:(NSArray *)data {
    [_tableView refreshFinished];
    
    self.iBegin--;
    [self.tableView reloadData];
}

- (void)dataLoad:(NSArray *)data {
    [_tableView loadMoreFinished];
    
    self.iEnd++;
    [self.tableView reloadData];
}


@end
