(function() {
    // Write your code below.

})(window.Zepto);
